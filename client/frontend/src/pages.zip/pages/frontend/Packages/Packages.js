import React from 'react'

export default function Packages() {
  return (
    <div>Packages</div>
  )
}
